# Statistical engine: conventions and reproduction

`statistics.js` is a dependency-free browser ES module. It performs no requests and reads no files. Original code is MIT licensed. Inputs must be arrays of finite numbers, with no silently dropped missing values. `analyze` accepts 20–10,000 observations; lag tests separately guard short, constant, or singular inputs. Arrays keep chronological order for diagnostics. Invalid calculations return `{valid:false, reason}`.

## Main API

- `analyze(values, {lags:10})` returns the object used by the teaching application.
- `generateSynthetic(kind, n=1500, seed=42)` returns deterministic unit-scale observations. Kinds: `normal`, `t5` (`t` alias), `garch`. The t5 innovations are multiplied by sqrt(3/5), so their population variance is one. GARCH uses Gaussian innovations, omega=.03, alpha=.12, beta=.85, h0=1, r0=0, and a 1,000-step burn-in; its stationary variance is one. Seeded PRNG is Mulberry32; normals use Box–Muller.
- `moments(values)` uses central moments with denominator n. `sd` is MLE/population-form sample SD; `sampleSD` uses n−1. Kurtosis is Pearson kurtosis; excess kurtosis subtracts three. `tail3Sigma` is the fraction with |x−mean| > 3 sd; `tail3SigmaCount` is the count.
- `normalFit(values)` estimates location and scale by ML, k=2.
- `studentFit(values)` jointly estimates location, scale and df with df constrained to [2.05,100], k=3. Standardized-data Nelder–Mead uses four starts plus explicit optimization on both df boundaries. `boundary` reports a boundary fit; `converged` reports numerical stopping. This is a bounded, finite-variance t family; scale is not SD. Model SD = scale sqrt(df/(df−2)).
- `acf(values,lags)` subtracts the full-sample mean. Every lag's numerator uses the same full-sample sum-of-squares denominator. `values[0]=1`.
- `ljungBox(values,lags)` computes n(n+2) sum[rho_k²/(n−k)] and the chi-square(df=lags) upper tail (model_df=0).
- `archLM(values,lags)` demeans returns, regresses squared demeaned returns on an intercept and p lagged squares, and computes (n−p)R² against chi-square(df=p), with no extra ddof adjustment. Reorthogonalized Gram–Schmidt detects rank deficiency.
- `jarqueBera(values)` uses n/6 [skewness² + excess_kurtosis²/4] and chi-square(df=2). This is a large-sample IID reference, not a finite-sample or dependence-robust p-value. The `largeSampleWarning` is true for n≤2000, following SciPy documentation's caution.
- `qqData(values,tFit,points=151)` samples order statistics at evenly spaced ranks and uses plotting positions (rank+.5)/n. `normal` and `student` are fitted-distribution quantiles in original units, `observed` is the empirical order statistic, `standardized` and `normalZ` are standardized normal QQ coordinates.
- `quantile(sorted,p)` uses linear interpolation of (n−1)p (NumPy's linear/type-7 convention).
- `histogram(values,bins=40)` spans the full empirical min–max and returns count/density/edges. All observations, including extrema, are included.
- `normalCDF`, `invNormal`, `normalPDF`; `studentCDF`, `invStudent`, `studentPDF`; `logGamma`, `chiSquareSF`.
- `formatP(p)` suppresses misleading numeric zero; every p below 1e−12 is displayed as `< 1e−12`. Numeric p may underflow internally and must not be narrated as certainty.

The `analyze` result contains `moments`, `normalFit`, `studentFit`, `deltaAIC` (normal AIC − t AIC; positive favors t), `jb`, `ljungBox` (`returns`, `absolute`, `squared`), `arch`, `qq`, `histogram`, and `quantiles`. Absolute/squared diagnostics transform **demeaned** returns. No likelihood-ratio p-value is claimed. Marginal model fits/AIC can summarize a dependent series but do not validate an IID model.

## Actual-data worked example

`statistics-reference.json` is a derived-only snapshot from the FRED SP500 CSV. Header was verified as `observation_date,SP500`. Window: 2020-01-02 through 2025-12-31, 1,508 nonmissing positive prices, 1,507 returns. Transform: log(Pt/Pprevious_available_observation), in decimal log-return units. Multiply location/scale/return-axis values by 100 for percentage display; do not rescale likelihood/AIC without refitting. Missing quote rows are dropped before differencing; no weekend/holiday forward-fill. This is a price index, not total return. Raw prices and raw chronological returns are not distributed.

`byLag['5']`, `byLag['10']`, `byLag['20']` contain complete `analyze` outputs. `analysis` aliases lag 10 in the serialized snapshot. Quantiles and histograms are derived summaries. This is a fixed historical example, not live data.

## Reproduction and independent checks

Install `numpy scipy pandas statsmodels` in your own Python environment, then:

    python validate_statistics.py --validate
    python validate_statistics.py --csv YOUR_FRED_SP500.csv --output statistics-reference.json

The validation invokes Node.js to compare browser-JavaScript outputs with SciPy and statsmodels on normal/t5/GARCH series for two seeds, plus short and constant samples. It also checks 45 Student t quantiles across df 2.05–100 and probabilities .0001–.9999. Student likelihood uses independent SciPy bounded multi-start optimization. `validation-results.json` records the executed checks. Results use unadjusted moments and statsmodels model_df=0 / ARCH ddof=0 conventions; changes to these conventions will change reference values.

## Interpretation limits

- Normality, absence of autocorrelation, independence and constant conditional variance are different claims.
- A significant JB test is not proof of Student t, power laws or any particular alternative.
- A nonsignificant result is not acceptance of its null hypothesis.
- Standard LB reference p-values can also be unreliable under conditional heteroskedasticity; all lag-test values are classroom reference calculations.
- ARCH rejection suggests predictable conditional second moments, not that one GARCH specification is correct.
- Repeated choice of lag/window/model creates multiplicity and selection issues.
- Tiny p-values are printed with a lower bound rather than as zero. Statistical significance is not economic importance.
- Fitting a distribution and then visually matching a QQ plot is in-sample description. No out-of-sample validation or valid fitted-parameter KS test is asserted.

## Primary methodological documentation

- SciPy Jarque–Bera: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.jarque_bera.html
- SciPy Student t: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.t.html
- statsmodels Ljung–Box: https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.acorr_ljungbox.html
- statsmodels ARCH LM: https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.het_arch.html
- FRED SP500 metadata: https://fred.stlouisfed.org/series/SP500
