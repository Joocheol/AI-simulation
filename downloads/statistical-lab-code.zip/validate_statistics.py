"""Reproduce return diagnostics and validate local JavaScript against SciPy/statsmodels.
Dependencies: numpy, scipy, pandas, statsmodels. Node.js required for --validate.
Usage: python validate_statistics.py --validate
       python validate_statistics.py --csv YOUR_FRED_SP500.csv --output sp500-reference.json
Input CSV: observation_date,SP500. Output contains only derived summaries, never raw prices.
All p-values are asymptotic reference values, not dependence-robust inference.
"""
import argparse,json,pathlib,subprocess,tempfile
import numpy as np
from scipy import stats,optimize,special
from statsmodels.stats.diagnostic import acorr_ljungbox,het_arch

def reference(x,lags=10):
    x=np.asarray(x,float); n=len(x); mu=x.mean(); sd=x.std(); z=(x-mu)/sd
    def objective(p):
        loc,ls,df=p
        return -stats.t.logpdf(z,df,loc=loc,scale=np.exp(ls)).sum()
    bounds=[(-20,20),(-8,5),(2.05,100)]
    fits=[optimize.minimize(objective,[0,.5*np.log((df-2)/df),df],method='Nelder-Mead',bounds=bounds,options={'maxiter':3000,'xatol':1e-9,'fatol':1e-9}) for df in [3,7,25,95]]
    fit=min(fits,key=lambda f:f.fun); l,ls,df=fit.x; ll=-fit.fun-n*np.log(sd)
    nll=stats.norm.logpdf(x,mu,sd).sum(); jb=stats.jarque_bera(x)
    lb={}
    for name,y in [('returns',x),('absolute',np.abs(x-mu)),('squared',(x-mu)**2)]:
        a=acorr_ljungbox(y,lags=[lags],model_df=0,return_df=True).iloc[0]
        lb[name]={'statistic':float(a.lb_stat),'pValue':float(a.lb_pvalue)}
    arch=het_arch(x-mu,nlags=lags,ddof=0)
    return dict(n=n,mean=float(mu),sd=float(sd),skewness=float(stats.skew(x)),excessKurtosis=float(stats.kurtosis(x)),normalFit=dict(loc=float(mu),scale=float(sd),logLikelihood=float(nll),aic=float(4-2*nll)),studentFit=dict(loc=float(mu+l*sd),scale=float(np.exp(ls)*sd),df=float(df),logLikelihood=float(ll),aic=float(6-2*ll)),deltaAIC=float((4-2*nll)-(6-2*ll)),jb=dict(statistic=float(jb.statistic),pValue=float(jb.pvalue)),ljungBox=lb,arch=dict(statistic=float(arch[0]),pValue=float(arch[1])))

def validate():
    here=pathlib.Path(__file__).resolve().parent
    runner="""import * as s from './statistics.js';
    const cases={};for(const kind of ['normal','t5','garch'])for(const seed of [42,123]){const x=s.generateSynthetic(kind,1500,seed);cases[kind+'_'+seed]={x,result:s.analyze(x)};}
    cases.small={x:[1,2,3],result:s.analyze([1,2,3])};cases.constant={x:Array(100).fill(1),result:s.analyze(Array(100).fill(1))};
    const special=[];for(const df of [2.05,3,5,30,100])for(const p of [.0001,.001,.01,.1,.5,.9,.99,.999,.9999])special.push({df,p,q:s.invStudent(p,df),cdf:s.studentCDF(s.invStudent(p,df),df)});
    console.log(JSON.stringify({cases,special}));"""
    js=here/'_validate_runner.mjs';js.write_text(runner)
    try: data=json.loads(subprocess.check_output(['node',str(js)],cwd=here))
    finally:js.unlink(missing_ok=True)
    report=[]
    for name,c in data['cases'].items():
        if name in ['small','constant']:
            assert not c['result']['valid'];report.append({'fixture':name,'passed':True});continue
        r=reference(c['x']); a=c['result']
        errors=[]
        for key in ['mean','sd','skewness','excessKurtosis']:
            np.testing.assert_allclose(a['moments'][key],r[key],rtol=1e-9,atol=1e-10)
        for key in ['jb','arch']:
            for field in ['statistic','pValue']:np.testing.assert_allclose(a[key][field],r[key][field],rtol=1e-8,atol=1e-10)
        for name2 in ['returns','absolute','squared']:
            for field in ['statistic','pValue']:np.testing.assert_allclose(a['ljungBox'][name2][field],r['ljungBox'][name2][field],rtol=1e-8,atol=1e-10)
        np.testing.assert_allclose(a['normalFit']['logLikelihood'],r['normalFit']['logLikelihood'],rtol=1e-10)
        np.testing.assert_allclose(a['studentFit']['logLikelihood'],r['studentFit']['logLikelihood'],atol=2e-5,rtol=0)
        report.append({'fixture':name,'passed':True,'studentLogLikelihoodAbsoluteError':abs(a['studentFit']['logLikelihood']-r['studentFit']['logLikelihood'])})
    for v in data['special']:
        np.testing.assert_allclose(v['q'],stats.t.ppf(v['p'],v['df']),rtol=2e-8,atol=1e-9)
        np.testing.assert_allclose(v['cdf'],v['p'],atol=2e-12)
    print(json.dumps({'validation':'passed','fixtures':report,'studentQuantileCases':len(data['special'])},indent=2))

def csv_reference(path,output):
    import pandas as pd
    df=pd.read_csv(path,na_values=['.','']);assert list(df.columns)==['observation_date','SP500']
    df['observation_date']=pd.to_datetime(df.observation_date)
    df=df[(df.observation_date>='2020-01-01')&(df.observation_date<='2025-12-31')].dropna().sort_values('observation_date')
    assert not df.observation_date.duplicated().any() and (df.SP500>0).all()
    x=np.diff(np.log(df.SP500.to_numpy()))
    result=reference(x)
    # Browser engine supplies downsampled diagnostic quantiles, no raw return sequence.
    here=pathlib.Path(__file__).resolve().parent
    runner="import fs from 'fs';import {analyze} from './statistics.js';const x=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(Object.fromEntries([5,10,20].map(lags=>[lags,analyze(x,{lags})]))));"
    js=here/'_reference_runner.mjs';js.write_text(runner)
    try:a=json.loads(subprocess.check_output(['node',str(js)],input=json.dumps(x.tolist()).encode(),cwd=here))
    finally:js.unlink(missing_ok=True)
    result={'source':{'name':'S&P 500 (FRED SP500)','url':'https://fred.stlouisfed.org/series/SP500','download':'https://fred.stlouisfed.org/graph/?id=SP500','priceStart':str(df.observation_date.iloc[0].date()),'priceEnd':str(df.observation_date.iloc[-1].date()),'returnStart':str(df.observation_date.iloc[1].date()),'priceCount':len(df),'returnCount':len(x),'transform':'log(P_t/P_previous_available_trading_observation)','units':'decimal log returns','missingPrices':'drop missing quoted prices before differencing; weekends/holidays not filled','retrieved':'2026-10-03','notTotalReturn':True,'redistribution':'Derived diagnostics only; no raw price or return series.'},'analysis':a['10'],'byLag':a,'pythonReference':result,'caveats':['IID reference p-values can be distorted by serial dependence and volatility clustering.','Marginal Student t is not a conditional volatility model.','AIC comparison is descriptive under serial dependence, and is not a significance test.','df constrained to [2.05,100]; upper boundary indicates near-normal within bounded family.','Historical index prices are not total returns and do not establish future behavior.']}
    pathlib.Path(output).write_text(json.dumps(result,indent=2,allow_nan=False));print(f'Wrote {output}; n={len(x)}; dates {df.observation_date.iloc[0].date()} to {df.observation_date.iloc[-1].date()}')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--validate',action='store_true');p.add_argument('--csv');p.add_argument('--output',default='sp500-reference.json');a=p.parse_args()
    if a.validate:validate()
    if a.csv:csv_reference(a.csv,a.output)
